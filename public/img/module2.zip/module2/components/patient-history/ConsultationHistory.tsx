'use client';

import { useState } from 'react';
import Link from 'next/link';

type Consultation = {
  id: string;
  date: string;
  reason: string;
  diagnosis: string;
  treatment: string;
  doctorName: string;
};

type Patient = {
  id: string;
  name: string;
  dateOfBirth: string;
  medicalRecordNumber: string;
};

export default function ConsultationHistory() {
  // Mock data for demonstration purposes
  const [patients] = useState<Patient[]>([
    {
      id: '1',
      name: 'Jean Dupont',
      dateOfBirth: '1975-05-15',
      medicalRecordNumber: 'MRN12345',
    },
    {
      id: '2',
      name: 'Marie Martin',
      dateOfBirth: '1982-11-23',
      medicalRecordNumber: 'MRN67890',
    },
    {
      id: '3',
      name: 'Pierre Durand',
      dateOfBirth: '1990-03-08',
      medicalRecordNumber: 'MRN24680',
    }
  ]);

  const [selectedPatient, setSelectedPatient] = useState<string>('');
  
  // Mock consultations data
  const [consultations] = useState<Record<string, Consultation[]>>({
    '1': [
      {
        id: '101',
        date: '2023-05-10T09:30:00',
        reason: 'Douleurs abdominales',
        diagnosis: 'Gastro-entérite',
        treatment: 'Repos, hydratation, médicaments anti-douleur',
        doctorName: 'Dr. Sophie Bernard'
      },
      {
        id: '102',
        date: '2023-03-22T14:15:00',
        reason: 'Suivi annuel',
        diagnosis: 'Examen normal',
        treatment: 'Aucun traitement nécessaire',
        doctorName: 'Dr. Michel Lefèvre'
      }
    ],
    '2': [
      {
        id: '201',
        date: '2023-06-05T11:00:00',
        reason: 'Hypertension',
        diagnosis: 'Hypertension artérielle',
        treatment: 'Prescription de médicaments antihypertenseurs',
        doctorName: 'Dr. Sophie Bernard'
      }
    ],
    '3': [
      {
        id: '301',
        date: '2023-04-18T10:45:00',
        reason: 'Douleurs au dos',
        diagnosis: 'Lombalgie',
        treatment: 'Kinésithérapie, anti-inflammatoires',
        doctorName: 'Dr. Michel Lefèvre'
      },
      {
        id: '302',
        date: '2023-02-03T16:30:00',
        reason: 'Rhume',
        diagnosis: 'Rhinopharyngite',
        treatment: 'Repos, hydratation, paracétamol',
        doctorName: 'Dr. Sophie Bernard'
      },
      {
        id: '303',
        date: '2022-11-15T09:00:00',
        reason: 'Vaccination',
        diagnosis: 'Aucun',
        treatment: 'Vaccination contre la grippe',
        doctorName: 'Dr. Michel Lefèvre'
      }
    ]
  });

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <label htmlFor="patient" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
          Sélectionner un patient
        </label>
        <select
          id="patient"
          value={selectedPatient}
          onChange={(e) => setSelectedPatient(e.target.value)}
          className="w-full p-2 border border-gray-300 dark:border-gray-700 rounded-md focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-800"
        >
          <option value="">-- Choisir un patient --</option>
          {patients.map((patient) => (
            <option key={patient.id} value={patient.id}>
              {patient.name} (Né(e) le {new Date(patient.dateOfBirth).toLocaleDateString('fr-FR')})
            </option>
          ))}
        </select>
      </div>

      {selectedPatient ? (
        consultations[selectedPatient]?.length > 0 ? (
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">
              Historique des consultations
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left text-gray-700 dark:text-gray-300">
                <thead className="text-xs uppercase bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300">
                  <tr>
                    <th scope="col" className="px-6 py-3">Date</th>
                    <th scope="col" className="px-6 py-3">Motif</th>
                    <th scope="col" className="px-6 py-3">Diagnostic</th>
                    <th scope="col" className="px-6 py-3">Traitement</th>
                    <th scope="col" className="px-6 py-3">Médecin</th>
                    <th scope="col" className="px-6 py-3">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {consultations[selectedPatient].map((consultation) => (
                    <tr key={consultation.id} className="bg-white dark:bg-gray-800 border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700">
                      <td className="px-6 py-4">{formatDate(consultation.date)}</td>
                      <td className="px-6 py-4">{consultation.reason}</td>
                      <td className="px-6 py-4">{consultation.diagnosis}</td>
                      <td className="px-6 py-4">{consultation.treatment}</td>
                      <td className="px-6 py-4">{consultation.doctorName}</td>
                      <td className="px-6 py-4">
                        <Link 
                          href={`/consultations/${consultation.id}`}
                          className="text-blue-600 dark:text-blue-400 hover:underline"
                        >
                          Voir détails
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500 dark:text-gray-400">
            <p>Aucune consultation trouvée pour ce patient.</p>
          </div>
        )
      ) : (
        <div className="text-center py-8 text-gray-500 dark:text-gray-400">
          <p>Veuillez sélectionner un patient pour voir son historique de consultations.</p>
        </div>
      )}
    </div>
  );
}