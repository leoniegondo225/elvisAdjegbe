'use client';

import { useState } from 'react';

type Patient = {
  id: string;
  name: string;
  dateOfBirth: string;
  medicalRecordNumber: string;
};

type HistoryEntry = {
  id: string;
  date: string;
  type: 'consultation' | 'treatment' | 'document';
  title: string;
  description: string;
};

export default function PatientHistoryView() {
  // Mock data for demonstration purposes
  const [patients] = useState<Patient[]>([
    {
      id: '1',
      name: 'Jean Dupont',
      dateOfBirth: '1975-05-15',
      medicalRecordNumber: 'MRN12345',
    },
    {
      id: '2',
      name: 'Marie Martin',
      dateOfBirth: '1982-09-23',
      medicalRecordNumber: 'MRN67890',
    },
    {
      id: '3',
      name: 'Pierre Durand',
      dateOfBirth: '1968-11-07',
      medicalRecordNumber: 'MRN54321',
    },
  ]);

  const [selectedPatient, setSelectedPatient] = useState<string | null>(null);
  
  // Mock history data
  const patientHistory: Record<string, HistoryEntry[]> = {
    '1': [
      {
        id: 'h1',
        date: '2023-06-15',
        type: 'consultation',
        title: 'Consultation générale',
        description: 'Douleurs abdominales. Diagnostic: Gastro-entérite',
      },
      {
        id: 'h2',
        date: '2023-05-10',
        type: 'treatment',
        title: 'Prescription médicaments',
        description: 'Antibiotiques pour infection respiratoire',
      },
      {
        id: 'h3',
        date: '2023-04-22',
        type: 'document',
        title: 'Résultats analyses sanguines',
        description: 'Bilan sanguin complet - Résultats normaux',
      },
    ],
    '2': [
      {
        id: 'h4',
        date: '2023-06-18',
        type: 'consultation',
        title: 'Suivi traitement hypertension',
        description: 'Tension artérielle stabilisée. Continuer le traitement actuel.',
      },
      {
        id: 'h5',
        date: '2023-03-05',
        type: 'document',
        title: 'Électrocardiogramme',
        description: 'ECG de contrôle - Rythme sinusal normal',
      },
    ],
    '3': [
      {
        id: 'h6',
        date: '2023-06-20',
        type: 'consultation',
        title: 'Examen annuel',
        description: 'Examen de routine programmé',
      },
    ],
  };

  // Get history entries for selected patient
  const getPatientHistory = () => {
    if (!selectedPatient) return [];
    return patientHistory[selectedPatient] || [];
  };

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
    });
  };

  // Get icon for history entry type
  const getEntryTypeIcon = (type: string) => {
    switch (type) {
      case 'consultation':
        return (
          <svg className="w-5 h-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
          </svg>
        );
      case 'treatment':
        return (
          <svg className="w-5 h-5 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
          </svg>
        );
      case 'document':
        return (
          <svg className="w-5 h-5 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
        );
      default:
        return null;
    }
  };

  return (
    <div>
      <div className="mb-6">
        <label htmlFor="patient-select" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          Sélectionner un patient
        </label>
        <select
          id="patient-select"
          className="bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 text-gray-900 dark:text-gray-300 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5"
          value={selectedPatient || ''}
          onChange={(e) => setSelectedPatient(e.target.value || null)}
        >
          <option value="">Choisir un patient</option>
          {patients.map((patient) => (
            <option key={patient.id} value={patient.id}>
              {patient.name} - {patient.medicalRecordNumber}
            </option>
          ))}
        </select>
      </div>

      {selectedPatient ? (
        <div className="space-y-4">
          <h2 className="text-xl font-semibold mb-4">
            Historique du patient: {patients.find(p => p.id === selectedPatient)?.name}
          </h2>
          
          {getPatientHistory().length === 0 ? (
            <p className="text-gray-500 dark:text-gray-400 italic">Aucun historique disponible pour ce patient.</p>
          ) : (
            <div className="relative border-l-2 border-gray-200 dark:border-gray-700 ml-3 pl-8 space-y-6">
              {getPatientHistory().map((entry) => (
                <div key={entry.id} className="relative">
                  <div className="absolute -left-10 mt-1.5 flex items-center justify-center w-6 h-6 rounded-full bg-white dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700">
                    {getEntryTypeIcon(entry.type)}
                  </div>
                  <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
                    <time className="text-sm font-normal leading-none text-gray-500 dark:text-gray-400">
                      {formatDate(entry.date)}
                    </time>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mt-1">
                      {entry.title}
                    </h3>
                    <p className="text-base font-normal text-gray-700 dark:text-gray-300 mt-1">
                      {entry.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        <div className="text-center py-8 text-gray-500 dark:text-gray-400">
          <p>Veuillez sélectionner un patient pour afficher son historique.</p>
        </div>
      )}
    </div>
  );
}