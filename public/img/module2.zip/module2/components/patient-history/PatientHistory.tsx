'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';

type Prescription = {
  id: string;
  patientName: string;
  date: string;
  medications: Array<{
    name: string;
    dosage: string;
    frequency: string;
  }>;
  reminderEnabled: boolean;
};

export default function PatientHistory() {
  const [prescriptions, setPrescriptions] = useState<Prescription[]>([
    {
      id: '1',
      patientName: 'Jean Dupont',
      date: '2023-06-15',
      medications: [
        { name: 'Paracétamol', dosage: '1g', frequency: 'toutes les 6 heures' }
      ],
      reminderEnabled: true
    }
  ]);

  const [activeReminders, setActiveReminders] = useState<string[]>([]);

  const triggerReminder = (medicationName: string) => {
    setActiveReminders(prev => [...prev, medicationName]);
    setTimeout(() => {
      setActiveReminders(prev => prev.filter(name => name !== medicationName));
    }, 5000);
  };

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-6">Historique des traitements</h2>
      
      {activeReminders.length > 0 && (
        <Alert variant="default" className="mb-4">
          <AlertDescription>
            ⏰ Rappel : Prendre {activeReminders.join(', ')} maintenant
          </AlertDescription>
        </Alert>
      )}

      <div className="space-y-4">
        {prescriptions.map(prescription => (
          <div key={prescription.id} className="border rounded-lg p-4">
            <div className="flex justify-between items-start mb-2">
              <div>
                <h3 className="font-semibold">{prescription.patientName}</h3>
                <p className="text-sm text-gray-600">{prescription.date}</p>
              </div>
              {prescription.reminderEnabled && (
                <Button
                  variant="outline"
                  onClick={() => prescription.medications.forEach(m => triggerReminder(m.name))}
                >
                  🔔 Rappeler
                </Button>
              )}
            </div>
            <div className="space-y-2">
              {prescription.medications.map((medication, index) => (
                <div key={index} className="flex justify-between items-center">
                  <div>
                    <p className="font-medium">{medication.name}</p>
                    <p className="text-sm text-gray-600">
                      {medication.dosage} - {medication.frequency}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}