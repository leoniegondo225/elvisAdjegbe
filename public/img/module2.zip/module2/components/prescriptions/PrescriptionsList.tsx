'use client';

import { useState } from 'react';
import Link from 'next/link';

type Prescription = {
  id: string;
  patientName: string;
  date: string;
  medications: Array<{
    name: string;
    dosage: string;
    frequency: string;
    duration: string;
  }>;
  instructions: string;
  doctorName: string;
  status: 'active' | 'completed' | 'cancelled';
};

export default function PrescriptionsList() {
  // Mock data for demonstration purposes
  const [prescriptions] = useState<Prescription[]>([
    {
      id: '1',
      patientName: 'Jean Dupont',
      date: '2023-06-15T10:30:00',
      medications: [
        {
          name: 'Amoxicilline',
          dosage: '500mg',
          frequency: '3 fois par jour',
          duration: '7 jours'
        },
        {
          name: 'Paracétamol',
          dosage: '1000mg',
          frequency: 'Si douleur, max 3 fois par jour',
          duration: 'Au besoin'
        }
      ],
      instructions: 'Prendre avec de la nourriture. Éviter l\'alcool pendant le traitement.',
      doctorName: 'Dr. Martin',
      status: 'active'
    },
    {
      id: '2',
      patientName: 'Marie Martin',
      date: '2023-06-18T15:45:00',
      medications: [
        {
          name: 'Amlodipine',
          dosage: '5mg',
          frequency: '1 fois par jour',
          duration: '30 jours'
        }
      ],
      instructions: 'Prendre le matin. Surveiller la tension artérielle régulièrement.',
      doctorName: 'Dr. Dubois',
      status: 'active'
    },
    {
      id: '3',
      patientName: 'Pierre Durand',
      date: '2023-05-20T09:15:00',
      medications: [
        {
          name: 'Ibuprofène',
          dosage: '400mg',
          frequency: '3 fois par jour',
          duration: '5 jours'
        }
      ],
      instructions: 'Prendre après les repas. Arrêter si douleurs gastriques.',
      doctorName: 'Dr. Martin',
      status: 'completed'
    }
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Filter prescriptions based on search term and status
  const filteredPrescriptions = prescriptions.filter(prescription => {
    const matchesSearch = prescription.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         prescription.medications.some(med => med.name.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesStatus = statusFilter === 'all' || prescription.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Get status badge class
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'completed':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'cancelled':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
    }
  };

  // Get status label
  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'active':
        return 'Active';
      case 'completed':
        return 'Terminée';
      case 'cancelled':
        return 'Annulée';
      default:
        return status;
    }
  };

  return (
    <div>
      <div className="mb-6 flex flex-col md:flex-row gap-4 justify-between">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <svg className="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
              <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"/>
            </svg>
          </div>
          <input
            type="search"
            className="block w-full p-2 pl-10 text-sm border border-gray-300 rounded-lg bg-white dark:bg-gray-800 dark:border-gray-700 focus:ring-blue-500 focus:border-blue-500"
            placeholder="Rechercher un patient ou un médicament..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <select
          className="bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 text-gray-900 dark:text-gray-300 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
        >
          <option value="all">Tous les statuts</option>
          <option value="active">Actives</option>
          <option value="completed">Terminées</option>
          <option value="cancelled">Annulées</option>
        </select>
      </div>

      {filteredPrescriptions.length === 0 ? (
        <div className="text-center py-8 text-gray-500 dark:text-gray-400">
          <p>Aucune prescription trouvée.</p>
        </div>
      ) : (
        <div className="space-y-6">
          {filteredPrescriptions.map((prescription) => (
            <div key={prescription.id} className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow">
              <div className="flex flex-col md:flex-row justify-between mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-blue-700 dark:text-blue-400">
                    {prescription.patientName}
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Prescrit le {formatDate(prescription.date)} par {prescription.doctorName}
                  </p>
                </div>
                <div className="mt-2 md:mt-0">
                  <span className={`px-3 py-1 rounded-full text-xs ${getStatusBadgeClass(prescription.status)}`}>
                    {getStatusLabel(prescription.status)}
                  </span>
                </div>
              </div>
              
              <div className="mb-4">
                <h4 className="text-md font-medium mb-2 text-gray-800 dark:text-gray-200">Médicaments</h4>
                <ul className="space-y-2">
                  {prescription.medications.map((med, index) => (
                    <li key={index} className="bg-gray-50 dark:bg-gray-700 p-3 rounded-md">
                      <div className="flex flex-col md:flex-row md:justify-between">
                        <span className="font-medium">{med.name}</span>
                        <span className="text-gray-600 dark:text-gray-400">{med.dosage}</span>
                      </div>
                      <div className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                        <span>{med.frequency}</span>
                        {med.duration && <span> • {med.duration}</span>}
                      </div>
                    </li>
                  ))}
                </ul>
              </div>
              
              {prescription.instructions && (
                <div className="mb-4">
                  <h4 className="text-md font-medium mb-2 text-gray-800 dark:text-gray-200">Instructions</h4>
                  <p className="text-gray-600 dark:text-gray-400 bg-gray-50 dark:bg-gray-700 p-3 rounded-md">
                    {prescription.instructions}
                  </p>
                </div>
              )}
              
              <div className="flex justify-end space-x-3">
                <Link 
                  href={`/prescriptions/${prescription.id}`}
                  className="text-blue-600 dark:text-blue-400 hover:underline"
                >
                  Voir détails
                </Link>
                {prescription.status === 'active' && (
                  <Link 
                    href={`/prescriptions/${prescription.id}/edit`}
                    className="text-blue-600 dark:text-blue-400 hover:underline"
                  >
                    Modifier
                  </Link>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}