'use client';

import { useState } from 'react';
import Link from 'next/link';

type TeleconsultationHistory = {
  id: string;
  patientName: string;
  date: string;
  reason: string;
  diagnosis: string;
  duration: string;
};

export default function TeleconsultationHistory() {
  // Mock data for demonstration purposes
  const [history] = useState<TeleconsultationHistory[]>([
    {
      id: '1',
      patientName: 'Jean Dupont',
      date: '2023-06-10T14:00:00',
      reason: 'Douleurs lombaires',
      diagnosis: 'Lombalgie chronique',
      duration: '25 minutes'
    },
    {
      id: '2',
      patientName: 'Marie Martin',
      date: '2023-06-05T09:30:00',
      reason: 'Suivi traitement hypertension',
      diagnosis: 'Hypertension contrôlée',
      duration: '15 minutes'
    },
    {
      id: '3',
      patientName: 'Sophie Petit',
      date: '2023-05-28T16:15:00',
      reason: 'Éruption cutanée',
      diagnosis: 'Dermatite de contact',
      duration: '20 minutes'
    }
  ]);

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div>
      {history.length === 0 ? (
        <div className="text-center py-8 text-gray-500 dark:text-gray-400">
          <p>Aucun historique de téléconsultation disponible.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {history.map((item) => (
            <div 
              key={item.id} 
              className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 bg-white dark:bg-gray-800"
            >
              <div className="flex flex-col md:flex-row justify-between">
                <div>
                  <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">
                    {item.patientName}
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {formatDate(item.date)}
                  </p>
                  <p className="text-sm text-gray-700 dark:text-gray-300 mt-1">
                    <span className="font-medium">Motif:</span> {item.reason}
                  </p>
                  <p className="text-sm text-gray-700 dark:text-gray-300">
                    <span className="font-medium">Diagnostic:</span> {item.diagnosis}
                  </p>
                  <p className="text-sm text-gray-700 dark:text-gray-300">
                    <span className="font-medium">Durée:</span> {item.duration}
                  </p>
                </div>
                
                <div className="mt-4 md:mt-0 flex items-center">
                  <Link 
                    href={`/teleconsultation/history/${item.id}`}
                    className="text-blue-600 dark:text-blue-400 hover:underline text-sm"
                  >
                    Voir détails
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}