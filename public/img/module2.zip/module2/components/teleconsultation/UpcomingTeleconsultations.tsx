'use client';

import { useState } from 'react';
import Link from 'next/link';
import { Button } from '@/components/ui/button';

type Teleconsultation = {
  id: string;
  patientName: string;
  date: string;
  reason: string;
  status: 'scheduled' | 'cancelled';
};

export default function UpcomingTeleconsultations() {
  // Mock data for demonstration purposes
  const [teleconsultations, setTeleconsultations] = useState<Teleconsultation[]>([
    {
      id: '1',
      patientName: 'Sophie Martin',
      date: '2023-07-15T10:00:00',
      reason: 'Suivi traitement allergie',
      status: 'scheduled'
    },
    {
      id: '2',
      patientName: 'Thomas Dubois',
      date: '2023-07-16T14:30:00',
      reason: 'Consultation dermatologique',
      status: 'scheduled'
    },
    {
      id: '3',
      patientName: 'Émilie Rousseau',
      date: '2023-07-18T09:15:00',
      reason: 'Renouvellement ordonnance',
      status: 'scheduled'
    }
  ]);

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Calculate time remaining until consultation
  const getTimeRemaining = (dateString: string) => {
    const consultationDate = new Date(dateString);
    const now = new Date();
    const diffTime = consultationDate.getTime() - now.getTime();
    
    if (diffTime <= 0) return 'Maintenant';
    
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    const diffHours = Math.floor((diffTime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    const diffMinutes = Math.floor((diffTime % (1000 * 60 * 60)) / (1000 * 60));
    
    if (diffDays > 0) {
      return `${diffDays} jour${diffDays > 1 ? 's' : ''} ${diffHours}h`;
    } else if (diffHours > 0) {
      return `${diffHours}h ${diffMinutes}min`;
    } else {
      return `${diffMinutes} minute${diffMinutes > 1 ? 's' : ''}`;
    }
  };

  // Cancel a teleconsultation
  const cancelTeleconsultation = (id: string) => {
    setTeleconsultations(prev => 
      prev.map(tc => 
        tc.id === id ? { ...tc, status: 'cancelled' as const } : tc
      )
    );
  };

  return (
    <div>
      {teleconsultations.length === 0 ? (
        <div className="text-center py-8 text-gray-500 dark:text-gray-400">
          <p>Vous n'avez pas de téléconsultations planifiées.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {teleconsultations.map((teleconsultation) => (
            <div 
              key={teleconsultation.id} 
              className={`border ${teleconsultation.status === 'cancelled' ? 'border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-900' : 'border-blue-200 dark:border-blue-900 bg-blue-50 dark:bg-blue-950'} rounded-lg p-4`}
            >
              <div className="flex flex-col md:flex-row justify-between">
                <div>
                  <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">
                    {teleconsultation.patientName}
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {formatDate(teleconsultation.date)}
                  </p>
                  <p className="text-sm text-gray-700 dark:text-gray-300 mt-1">
                    {teleconsultation.reason}
                  </p>
                </div>
                
                <div className="mt-4 md:mt-0 flex flex-col items-start md:items-end justify-between">
                  {teleconsultation.status === 'scheduled' ? (
                    <>
                      <span className="text-sm font-medium text-blue-700 dark:text-blue-400">
                        Dans {getTimeRemaining(teleconsultation.date)}
                      </span>
                      <div className="mt-2 space-x-2 flex">
                        <Link href={`/teleconsultation/${teleconsultation.id}`}>
                          <Button 
                            className="bg-blue-600 hover:bg-blue-700 text-white text-black text-sm px-3 py-1"
                          >
                            Rejoindre
                          </Button>
                        </Link>
                        <Link href={`/teleconsultation/history/${teleconsultation.id}`}>
<Button variant="outline" className="text-sm px-3 py-1 mr-2">Voir détails</Button>
</Link>
<Button 
                          variant="outline" 
                          className="text-sm px-3 py-1 border-red-300 text-red-600 hover:bg-red-50"
                          onClick={() => cancelTeleconsultation(teleconsultation.id)}
                        >
                          Annuler
                        </Button>
                      </div>
                    </>
                  ) : (
                    <span className="px-2 py-1 rounded-full text-xs bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300">
                      Annulée
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}