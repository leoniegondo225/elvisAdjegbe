'use client';

import { useState } from 'react';

type CalendarDay = {
  date: number;
  isCurrentMonth: boolean;
  hasAppointments: boolean;
  appointments?: Array<{
    id: string;
    time: string;
    patientName: string;
    reason: string;
  }>;
};

type Appointment = {
  id: string;
  time: string;
  patientName: string;
  reason: string;
};

type AppointmentsRecord = Record<string, Appointment[]>;

export function Calendar() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  
  // Mock data for demonstration purposes
  const mockAppointments: AppointmentsRecord = {
    '2023-06-15': [
      { id: '1', time: '09:00', patientName: 'Jean Dupont', reason: 'Consultation générale' },
      { id: '2', time: '11:30', patientName: 'Marie Martin', reason: 'Suivi traitement' },
    ],
    '2023-06-18': [
      { id: '3', time: '14:00', patientName: 'Pierre Durand', reason: 'Examen annuel' },
    ],
  };

  // Generate calendar days for the current month view
  const generateCalendarDays = (): CalendarDay[] => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    
    const firstDayOfMonth = new Date(year, month, 1);
    const lastDayOfMonth = new Date(year, month + 1, 0);
    
    const daysInMonth = lastDayOfMonth.getDate();
    const startingDayOfWeek = firstDayOfMonth.getDay(); // 0 = Sunday, 1 = Monday, etc.
    
    const calendarDays: CalendarDay[] = [];
    
    // Add days from previous month to fill the first week
    const daysInPrevMonth = new Date(year, month, 0).getDate();
    
    for (let i = startingDayOfWeek - 1; i >= 0; i--) {
      calendarDays.push({
        date: daysInPrevMonth - i,
        isCurrentMonth: false,
        hasAppointments: false
      });
    }
    
    // Add days of current month
    for (let day = 1; day <= daysInMonth; day++) {
      const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const hasAppointments = mockAppointments[dateStr] !== undefined;
      
      calendarDays.push({
        date: day,
        isCurrentMonth: true,
        hasAppointments,
        appointments: mockAppointments[dateStr]
      });
    }
    
    // Add days from next month to complete the calendar grid (6 rows x 7 days = 42 cells)
    const remainingDays = 42 - calendarDays.length;
    for (let day = 1; day <= remainingDays; day++) {
      calendarDays.push({
        date: day,
        isCurrentMonth: false,
        hasAppointments: false
      });
    }
    
    return calendarDays;
  };

  const calendarDays = generateCalendarDays();
  
  const handlePrevMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
  };
  
  const handleNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
  };
  
  const handleDateClick = (day: CalendarDay) => {
    if (day.isCurrentMonth) {
      setSelectedDate(new Date(currentDate.getFullYear(), currentDate.getMonth(), day.date));
    }
  };

  // Format the month and year for display
  const monthYearString = currentDate.toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' });
  
  // Day names in French
  const dayNames = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];

  return (
    <div className="calendar-container">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-semibold text-blue-700 capitalize">{monthYearString}</h2>
        <div className="flex space-x-2">
          <button 
            onClick={handlePrevMonth}
            className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <button 
            onClick={handleNextMonth}
            className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        </div>
      </div>
      
      <div className="grid grid-cols-7 gap-1">
        {/* Day names */}
        {dayNames.map((day) => (
          <div key={day} className="text-center font-medium text-gray-500 dark:text-gray-400 py-2">
            {day}
          </div>
        ))}
        
        {/* Calendar days */}
        {calendarDays.map((day, index) => (
          <div 
            key={index}
            onClick={() => handleDateClick(day)}
            className={`
              relative p-2 h-16 border border-gray-200 dark:border-gray-700 rounded-md
              ${day.isCurrentMonth ? 'bg-white dark:bg-gray-800' : 'bg-gray-50 dark:bg-gray-900 text-gray-400 dark:text-gray-600'}
              ${selectedDate && day.isCurrentMonth && day.date === selectedDate.getDate() ? 'ring-2 ring-blue-500' : ''}
              hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer transition-colors
            `}
          >
            <span className="text-sm">{day.date}</span>
            
            {day.hasAppointments && (
              <div className="absolute bottom-1 right-1 w-2 h-2 bg-blue-500 rounded-full"></div>
            )}
            
            {day.appointments && day.appointments.length > 0 && (
              <div className="mt-1">
                {day.appointments.slice(0, 2).map((apt) => (
                  <div key={apt.id} className="text-xs truncate text-blue-600 dark:text-blue-400">
                    {apt.time} - {apt.patientName}
                  </div>
                ))}
                {day.appointments.length > 2 && (
                  <div className="text-xs text-gray-500 dark:text-gray-400">
                    +{day.appointments.length - 2} plus
                  </div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
      
      {/* Selected date appointments */}
      {selectedDate && (
        <div className="mt-6 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
          <h3 className="font-medium mb-2">
            Rendez-vous du {selectedDate.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' })}
          </h3>
          
          {(() => {
            const dateStr = `${selectedDate.getFullYear()}-${String(selectedDate.getMonth() + 1).padStart(2, '0')}-${String(selectedDate.getDate()).padStart(2, '0')}`;
            const appointments = mockAppointments[dateStr] || [];
            
            if (appointments.length === 0) {
              return <p className="text-gray-500 dark:text-gray-400 text-sm">Aucun rendez-vous prévu pour cette date.</p>;
            }
            
            return (
              <div className="space-y-2">
                {appointments.map((apt: Appointment) => (
                  <div key={apt.id} className="p-3 bg-white dark:bg-gray-800 rounded-md shadow-sm">
                    <div className="flex justify-between">
                      <span className="font-medium">{apt.time}</span>
                      <span className="text-blue-600 dark:text-blue-400">{apt.patientName}</span>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">{apt.reason}</p>
                  </div>
                ))}
              </div>
            );
          })()} 
        </div>
      )}
    </div>
  );
}