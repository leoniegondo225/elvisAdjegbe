'use client';

import { PDFDownloadLink } from '@react-pdf/renderer';
import type { Consultation } from './ConsultationsList';
import { ReportDocument } from './ReportDocument';

const MedicalReportTemplate = ({ consultation }: { consultation: Consultation }) => (
  <div className="mt-4">
    <PDFDownloadLink
      document={<ReportDocument consultation={consultation} />}
      fileName={`rapport-${consultation.id}.pdf`}
    >
      {({ loading }: { loading: boolean }) => (
        <button 
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 disabled:bg-gray-400"
          disabled={loading}
        >
          {loading ? 'Génération...' : '📥 Télécharger le rapport'}
        </button>
      )}
    </PDFDownloadLink>
  </div>
);

export default MedicalReportTemplate;