'use client';

import { useState } from 'react';
import Link from 'next/link';

export type Consultation = {
  id: string;
  patientName: string;
  date: string;
  reason: string;
  diagnosis: string;
  treatment: string;
  notes: string;
  status: 'completed' | 'scheduled' | 'cancelled';
};

export default function ConsultationsList() {
  // Mock data for demonstration purposes
  const [consultations] = useState<Consultation[]>([
    {
      id: '1',
      patientName: 'Jean Dupont',
      date: '2023-06-15T09:00:00',
      reason: 'Douleurs abdominales',
      diagnosis: 'Gastro-entérite',
      treatment: 'Repos, hydratation, médicaments anti-douleur',
      notes: 'Patient à revoir dans une semaine',
      status: 'completed'
    },
    {
      id: '2',
      patientName: 'Marie Martin',
      date: '2023-06-18T14:30:00',
      reason: 'Suivi traitement hypertension',
      diagnosis: 'Hypertension contrôlée',
      treatment: 'Continuer le traitement actuel',
      notes: 'Contrôle tensionnel satisfaisant',
      status: 'completed'
    },
    {
      id: '3',
      patientName: 'Pierre Durand',
      date: '2023-06-20T11:00:00',
      reason: 'Examen annuel',
      diagnosis: 'En attente',
      treatment: 'En attente',
      notes: 'Rendez-vous de suivi nécessaire',
      status: 'scheduled'
    }
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  // Filter consultations based on search term and status
  const filteredConsultations = consultations.filter(consultation => {
    const matchesSearch = consultation.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         consultation.reason.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || consultation.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Get status badge class
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'scheduled':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'cancelled':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
    }
  };

  // Get status label
  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'completed':
        return 'Terminée';
      case 'scheduled':
        return 'Planifiée';
      case 'cancelled':
        return 'Annulée';
      default:
        return status;
    }
  };

  return (
    <div>
      <div className="mb-6 flex flex-col md:flex-row gap-4 justify-between">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <svg className="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
              <path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z"/>
            </svg>
          </div>
          <input
            type="search"
            className="block w-full p-2 pl-10 text-sm border border-gray-300 rounded-lg bg-white dark:bg-gray-800 dark:border-gray-700 focus:ring-blue-500 focus:border-blue-500"
            placeholder="Rechercher un patient ou un motif..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <select
          className="bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 text-gray-900 dark:text-gray-300 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5"
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
        >
          <option value="all">Tous les statuts</option>
          <option value="completed">Terminées</option>
          <option value="scheduled">Planifiées</option>
          <option value="cancelled">Annulées</option>
        </select>
      </div>

      {filteredConsultations.length === 0 ? (
        <div className="text-center py-8 text-gray-500 dark:text-gray-400">
          <p>Aucune consultation trouvée.</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left text-gray-700 dark:text-gray-300">
            <thead className="text-xs uppercase bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300">
              <tr>
                <th scope="col" className="px-6 py-3">Patient</th>
                <th scope="col" className="px-6 py-3">Date</th>
                <th scope="col" className="px-6 py-3">Motif</th>
                <th scope="col" className="px-6 py-3">Diagnostic</th>
                <th scope="col" className="px-6 py-3">Statut</th>
                <th scope="col" className="px-6 py-3">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredConsultations.map((consultation) => (
                <tr key={consultation.id} className="bg-white dark:bg-gray-800 border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-700">
                  <td className="px-6 py-4 font-medium">{consultation.patientName}</td>
                  <td className="px-6 py-4">{formatDate(consultation.date)}</td>
                  <td className="px-6 py-4">{consultation.reason}</td>
                  <td className="px-6 py-4">
                    {consultation.status === 'scheduled' ? (
                      <span className="text-gray-500 dark:text-gray-400 italic">En attente</span>
                    ) : (
                      consultation.diagnosis
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-full text-xs ${getStatusBadgeClass(consultation.status)}`}>
                      {getStatusLabel(consultation.status)}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <Link 
                      href={`/consultations/${consultation.id}`}
                      className="text-blue-600 dark:text-blue-400 hover:underline mr-3"
                    >
                      Voir
                    </Link>
                    {consultation.status === 'scheduled' && (
                      <Link 
                        href={`/consultations/${consultation.id}/edit`}
                        className="text-blue-600 dark:text-blue-400 hover:underline"
                      >
                        Modifier
                      </Link>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}