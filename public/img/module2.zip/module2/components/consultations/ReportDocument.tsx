import { Page, Text, View, Document, StyleSheet } from '@react-pdf/renderer';
import type { Consultation } from './ConsultationsList';

const styles = StyleSheet.create({
  page: {
    padding: 30
  },
  header: {
    fontSize: 24,
    marginBottom: 20,
    textAlign: 'center'
  },
  section: {
    marginBottom: 10
  },
  label: {
    fontSize: 12,
    color: '#666'
  },
  value: {
    fontSize: 14,
    marginBottom: 5
  }
});

export const ReportDocument = ({ consultation }: { consultation: Consultation }) => (
  <Document>
    <Page size="A4" style={styles.page}>
      <View style={styles.header}>
        <Text>Rapport Médical</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.label}>Patient:</Text>
        <Text style={styles.value}>{consultation.patientName}</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.label}>Date de consultation:</Text>
        <Text style={styles.value}>{new Date(consultation.date).toLocaleDateString('fr-FR')}</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.label}>Motif de consultation:</Text>
        <Text style={styles.value}>{consultation.reason}</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.label}>Diagnostic:</Text>
        <Text style={styles.value}>{consultation.diagnosis}</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.label}>Traitement prescrit:</Text>
        <Text style={styles.value}>{consultation.treatment}</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.label}>Notes supplémentaires:</Text>
        <Text style={styles.value}>{consultation.notes}</Text>
      </View>
    </Page>
  </Document>
);