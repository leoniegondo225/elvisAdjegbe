import PatientHistoryView from '@/components/patient-history/PatientHistoryView';
import ConsultationHistory from '@/components/patient-history/ConsultationHistory';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function PatientHistoryPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-blue-700 mb-6">Historique des Soins</h1>
      
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="overview">Vue d'ensemble</TabsTrigger>
          <TabsTrigger value="consultations">Consultations</TabsTrigger>
          <TabsTrigger value="treatments">Traitements</TabsTrigger>
          <TabsTrigger value="documents">Documents</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <PatientHistoryView />
          </div>
        </TabsContent>
        
        <TabsContent value="consultations" className="space-y-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4">Historique des consultations</h2>
            <ConsultationHistory />
          </div>
        </TabsContent>
        
        <TabsContent value="treatments" className="space-y-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4">Historique des traitements</h2>
            <p className="text-gray-500 dark:text-gray-400 italic">Sélectionnez un patient pour voir son historique de traitements.</p>
            {/* Historique des traitements sera implémenté ici */}
          </div>
        </TabsContent>
        
        <TabsContent value="documents" className="space-y-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4">Documents médicaux</h2>
            <p className="text-gray-500 dark:text-gray-400 italic">Sélectionnez un patient pour voir ses documents médicaux.</p>
            {/* Documents médicaux seront implémentés ici */}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}