import Image from "next/image";
import Link from "next/link";

export default function Home() {
  const features = [
    {
      title: "Agenda du Médecin",
      description: "Planifiez vos consultations en temps réel et suivez vos disponibilités.",
      icon: "/agenda.svg",
      link: "/schedule"
    },
    {
      title: "Consultations Médicales",
      description: "Gérez les motifs de consultation, diagnostics et recommandations de traitement.",
      icon: "/consultation.svg",
      link: "/consultations"
    },
    {
      title: "Prescriptions",
      description: "Créez et gérez des prescriptions médicales et des conseils personnalisés.",
      icon: "/file.svg",
      link: "/prescriptions"
    },
    {
      title: "Téléconsultation",
      description: "Effectuez des consultations vidéo sécurisées avec messagerie intégrée.",
      icon: "/Téléconsultation.svg",
      link: "/teleconsultation"
    },
    {
      title: "Historique des Soins",
      description: "Accédez à l'historique complet des soins et au suivi des traitements.",
      icon: "/Historique.svg",
      link: "/patient-history"
    }
  ];

  return (
    <div className="container mx-auto px-4 py-12">
      {/* Hero Section */}
      <section className="text-center mb-16">
        <h1 className="text-4xl md:text-5xl font-bold mb-6 text-blue-700">
          MediManage
        </h1>
        <p className="text-xl max-w-3xl mx-auto text-gray-600 dark:text-gray-300">
          Optimisez vos consultations et améliorez les soins aux patients avec notre système de gestion médicale complet.
        </p>
      </section>

      {/* Features Section */}
      <section className="mb-16">
        <h2 className="text-2xl md:text-3xl font-semibold mb-8 text-center text-blue-800">
          Fonctionnalités principales
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Link 
              key={index} 
              href={feature.link}
              className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow border border-gray-100 dark:border-gray-700"
            >
              <div className="flex items-start mb-4">
                <div className="bg-blue-100 dark:bg-blue-900 p-3 rounded-md mr-4">
                  <Image 
                    src={feature.icon} 
                    alt={feature.title} 
                    width={24} 
                    height={24} 
                    className="text-blue-600 dark:text-blue-400"
                  />
                </div>
                <h3 className="text-xl font-semibold text-blue-700 dark:text-blue-300">
                  {feature.title}
                </h3>
              </div>
              <p className="text-gray-600 dark:text-gray-300">
                {feature.description}
              </p>
            </Link>
          ))}
        </div>
      </section>

      {/* Benefits Section */}
      <section className="bg-blue-50 dark:bg-gray-800 p-8 rounded-xl mb-16">
        <h2 className="text-2xl md:text-3xl font-semibold mb-8 text-center text-blue-800 dark:text-blue-200">
          Avantages pour votre pratique médicale
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="flex items-start">
            <div className="bg-blue-100 dark:bg-blue-800 p-2 rounded-full mr-4">
              <svg className="w-6 h-6 text-blue-600 dark:text-blue-300" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <div>
              <h3 className="text-lg font-medium text-blue-700 dark:text-blue-300 mb-2">Gain de temps considérable</h3>
              <p className="text-gray-600 dark:text-gray-300">Réduisez le temps consacré aux tâches administratives et concentrez-vous sur vos patients.</p>
            </div>
          </div>
          <div className="flex items-start">
            <div className="bg-blue-100 dark:bg-blue-800 p-2 rounded-full mr-4">
              <svg className="w-6 h-6 text-blue-600 dark:text-blue-300" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <div>
              <h3 className="text-lg font-medium text-blue-700 dark:text-blue-300 mb-2">Amélioration de la qualité des soins</h3>
              <p className="text-gray-600 dark:text-gray-300">Accédez rapidement à l'historique complet des patients pour des décisions médicales éclairées.</p>
            </div>
          </div>
          <div className="flex items-start">
            <div className="bg-blue-100 dark:bg-blue-800 p-2 rounded-full mr-4">
              <svg className="w-6 h-6 text-blue-600 dark:text-blue-300" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <div>
              <h3 className="text-lg font-medium text-blue-700 dark:text-blue-300 mb-2">Réduction des erreurs médicales</h3>
              <p className="text-gray-600 dark:text-gray-300">Minimisez les risques d'erreurs grâce à un système de suivi précis des traitements et prescriptions.</p>
            </div>
          </div>
          <div className="flex items-start">
            <div className="bg-blue-100 dark:bg-blue-800 p-2 rounded-full mr-4">
              <svg className="w-6 h-6 text-blue-600 dark:text-blue-300" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <div>
              <h3 className="text-lg font-medium text-blue-700 dark:text-blue-300 mb-2">Satisfaction accrue des patients</h3>
              <p className="text-gray-600 dark:text-gray-300">Offrez une expérience plus fluide et personnalisée à vos patients grâce à des outils modernes.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
