import TeleconsultationInterface from '@/components/teleconsultation/TeleconsultationInterface';
import UpcomingTeleconsultations from '@/components/teleconsultation/UpcomingTeleconsultations';
import TeleconsultationHistory from '@/components/teleconsultation/TeleconsultationHistory';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function TeleconsultationPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-blue-700 mb-6">Téléconsultation</h1>
      
      <Tabs defaultValue="active" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="active">Consultation en cours</TabsTrigger>
          <TabsTrigger value="upcoming">À venir</TabsTrigger>
          <TabsTrigger value="history">Historique</TabsTrigger>
        </TabsList>
        
        <TabsContent value="active" className="space-y-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <TeleconsultationInterface />
          </div>
        </TabsContent>
        
        <TabsContent value="upcoming" className="space-y-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4">Téléconsultations à venir</h2>
            <UpcomingTeleconsultations />
          </div>
        </TabsContent>
        
        <TabsContent value="history" className="space-y-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4">Historique des téléconsultations</h2>
            <TeleconsultationHistory />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}