'use client';

import { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
// Removing unused Link import
import { Button } from '@/components/ui/button';

type TeleconsultationDetails = {
  id: string;
  patientName: string;
  date: string;
  duration: string;
  reason: string;
  notes: string;
  status: string;
  recordingUrl?: string;
};

export default function TeleconsultationHistoryDetail() {
  const router = useRouter();
  const params = useParams();
  const [isLoading, setIsLoading] = useState(true);
  const [details, setDetails] = useState<TeleconsultationDetails | null>(null);

  useEffect(() => {
    // Simulated API call to fetch consultation details
    setTimeout(() => {
      setDetails({
        id: params.id as string,
        patientName: 'Marie Dupont',
        date: '2023-07-15',
        duration: '45 minutes',
        reason: 'Suivi traitement chronique',
        notes: 'Le patient présente une amélioration des symptômes. Continuer le traitement actuel.',
        status: 'Terminé',
        recordingUrl: '/uploads/consultation123.mp4'
      });
      setIsLoading(false);
    }, 800);
  }, [params.id]);

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="space-y-2">
            <div className="h-4 bg-gray-200 rounded w-1/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-blue-700 mb-2">Détails de la Téléconsultation</h1>
        <p className="text-gray-600 dark:text-gray-400">
          Consultation du {details?.date} avec {details?.patientName}
        </p>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="font-semibold text-gray-700 dark:text-gray-300 mb-2">Informations Patient</h3>
            <p className="text-gray-600 dark:text-gray-400">{details?.patientName}</p>
          </div>
          
          <div>
            <h3 className="font-semibold text-gray-700 dark:text-gray-300 mb-2">Durée</h3>
            <p className="text-gray-600 dark:text-gray-400">{details?.duration}</p>
          </div>

          <div>
            <h3 className="font-semibold text-gray-700 dark:text-gray-300 mb-2">Statut</h3>
            <p className="text-blue-600 dark:text-blue-400">{details?.status}</p>
          </div>

          {details?.recordingUrl && (
            <div>
              <h3 className="font-semibold text-gray-700 dark:text-gray-300 mb-2">Enregistrement</h3>
              <a 
                href={details.recordingUrl}
                className="text-blue-600 hover:text-blue-800 dark:text-blue-400"
                target="_blank"
                rel="noopener noreferrer"
              >
                Voir l'enregistrement
              </a>
            </div>
          )}
        </div>

        <div>
          <h3 className="font-semibold text-gray-700 dark:text-gray-300 mb-2">Motif de consultation</h3>
          <p className="text-gray-600 dark:text-gray-400">{details?.reason}</p>
        </div>

        <div>
          <h3 className="font-semibold text-gray-700 dark:text-gray-300 mb-2">Notes médicales</h3>
          <p className="text-gray-600 dark:text-gray-400 whitespace-pre-line">{details?.notes}</p>
        </div>

        <div className="flex justify-end">
          <Button 
            onClick={() => router.back()}
            className="bg-blue-600 hover:bg-blue-700 text-white"
          >
            Retour à l&apos;historique
          </Button>
        </div>
      </div>
    </div>
  );
}