import PrescriptionsList from '@/components/prescriptions/PrescriptionsList';
import NewPrescriptionButton from '@/components/prescriptions/NewPrescriptionButton';

export default function PrescriptionsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-blue-700">Prescriptions Médicales</h1>
        <NewPrescriptionButton />
      </div>
      
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <PrescriptionsList />
      </div>
    </div>
  );
}