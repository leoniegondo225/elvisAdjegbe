'use client';

import { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { Button } from '@/components/ui/button';

export default function EditPrescriptionPage() {
    const router = useRouter();
    const params = useParams();
    const prescriptionId = params.id as string;
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isLoading, setIsLoading] = useState(true);

    // Form state
    const [formData, setFormData] = useState({
        patientName: '',
        medications: [
            {
                name: '',
                dosage: '',
                frequency: '',
                duration: ''
            }
        ],
        instructions: ''
    });

    // Récupérer les données de prescription
    useEffect(() => {
        // Dans une application réelle, vous récupéreriez les données à partir de votre API
        // Pour l'instant, nous allons simuler la récupération de données
        const fetchData = () => {
            setIsLoading(true);

            // Données fictives basées sur l'ID de prescription
            // Dans une application réelle, il s'agirait d'un appel d'API
            setTimeout(() => {
                // Il s'agit de données fictives - dans une application réelle, vous récupéreriez à partir d'une API
                const mockPrescriptions = [
                    {
                        id: '1',
                        patientName: 'Jean Dupont',
                        medications: [
                            {
                                name: 'Amoxicilline',
                                dosage: '500mg',
                                frequency: '3 fois par jour',
                                duration: '7 jours'
                            },
                            {
                                name: 'Paracétamol',
                                dosage: '1000mg',
                                frequency: 'Si douleur, max 3 fois par jour',
                                duration: 'Au besoin'
                            }
                        ],
                        instructions: 'Prendre avec de la nourriture. Éviter l\'alcool pendant le traitement.',
                        status: 'active'
                    },
                    {
                        id: '2',
                        patientName: 'Marie Martin',
                        medications: [
                            {
                                name: 'Amlodipine',
                                dosage: '5mg',
                                frequency: '1 fois par jour',
                                duration: '30 jours'
                            }
                        ],
                        instructions: 'Prendre le matin. Surveiller la tension artérielle régulièrement.',
                        status: 'active'
                    },
                    {
                        id: '3',
                        patientName: 'Pierre Durand',
                        medications: [
                            {
                                name: 'Ibuprofène',
                                dosage: '400mg',
                                frequency: '3 fois par jour',
                                duration: '5 jours'
                            }
                        ],
                        instructions: 'Prendre après les repas. Arrêter si douleurs gastriques.',
                        status: 'completed'
                    }
                ];

                const prescription = mockPrescriptions.find(p => p.id === prescriptionId);

                if (prescription) {
                    setFormData({
                        patientName: prescription.patientName,
                        medications: prescription.medications,
                        instructions: prescription.instructions || ''
                    });
                } else {
                    // Handle case where prescription is not found
                    router.push('/prescriptions');
                }

                setIsLoading(false);
            }, 1000);
        };

        fetchData();
    }, [prescriptionId, router]);

    // Handle form input changes
    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    // Handle medication input changes
    const handleMedicationChange = (index: number, field: string, value: string) => {
        const updatedMedications = [...formData.medications];
        updatedMedications[index] = {
            ...updatedMedications[index],
            [field]: value
        };

        setFormData(prev => ({
            ...prev,
            medications: updatedMedications
        }));
    };

    // Add new medication field
    const addMedication = () => {
        setFormData(prev => ({
            ...prev,
            medications: [
                ...prev.medications,
                { name: '', dosage: '', frequency: '', duration: '' }
            ]
        }));
    };

    // Remove medication field
    const removeMedication = (index: number) => {
        if (formData.medications.length > 1) {
            const updatedMedications = [...formData.medications];
            updatedMedications.splice(index, 1);

            setFormData(prev => ({
                ...prev,
                medications: updatedMedications
            }));
        }
    };

    // Handle form submission
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);

        // Here you would typically send the data to your API
        // For now, we'll just simulate a submission
        setTimeout(() => {
            setIsSubmitting(false);
            // Navigate back to prescriptions list
            router.push('/prescriptions');
        }, 1500);
    };

    if (isLoading) {
        return (
            <div className="container mx-auto px-4 py-8">
                <div className="flex justify-center items-center h-64">
                    <p className="text-gray-500 dark:text-gray-400">Chargement des données...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="container mx-auto px-4 py-8">
            <div className="mb-6">
                <h1 className="text-3xl font-bold text-blue-700">Modifier la Prescription</h1>
                <p className="text-gray-600 dark:text-gray-400 mt-2">Modifiez les informations de la prescription</p>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="space-y-4">
                        <div className="space-y-2">
                            <label htmlFor="patientName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                                Nom du patient
                            </label>
                            <input
                                type="text"
                                id="patientName"
                                name="patientName"
                                value={formData.patientName}
                                onChange={handleChange}
                                required
                                className="w-full p-2 border border-gray-300 dark:border-gray-700 rounded-md focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-800"
                            />
                        </div>

                        <div className="space-y-4">
                            <div className="flex justify-between items-center">
                                <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">Médicaments</h3>
                                <Button
                                    type="button"
                                    onClick={addMedication}
                                    variant="outline"
                                    className="text-sm px-3 py-1"
                                >
                                    + Ajouter un médicament
                                </Button>
                            </div>

                            {formData.medications.map((medication, index) => (
                                <div key={index} className="p-4 border border-gray-200 dark:border-gray-700 rounded-md space-y-4">
                                    <div className="flex justify-between items-center">
                                        <h4 className="text-md font-medium">Médicament {index + 1}</h4>
                                        {formData.medications.length > 1 && (
                                            <button
                                                type="button"
                                                onClick={() => removeMedication(index)}
                                                className="text-red-500 hover:text-red-700 text-sm"
                                            >
                                                Supprimer
                                            </button>
                                        )}
                                    </div>

                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div className="space-y-2">
                                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                                                Nom du médicament
                                            </label>
                                            <input
                                                type="text"
                                                value={medication.name}
                                                onChange={(e) => handleMedicationChange(index, 'name', e.target.value)}
                                                required
                                                className="w-full p-2 border border-gray-300 dark:border-gray-700 rounded-md focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-800"
                                            />
                                        </div>

                                        <div className="space-y-2">
                                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                                                Dosage
                                            </label>
                                            <input
                                                type="text"
                                                value={medication.dosage}
                                                onChange={(e) => handleMedicationChange(index, 'dosage', e.target.value)}
                                                required
                                                className="w-full p-2 border border-gray-300 dark:border-gray-700 rounded-md focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-800"
                                            />
                                        </div>

                                        <div className="space-y-2">
                                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                                                Fréquence
                                            </label>
                                            <input
                                                type="text"
                                                value={medication.frequency}
                                                onChange={(e) => handleMedicationChange(index, 'frequency', e.target.value)}
                                                required
                                                className="w-full p-2 border border-gray-300 dark:border-gray-700 rounded-md focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-800"
                                            />
                                        </div>

                                        <div className="space-y-2">
                                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                                                Durée
                                            </label>
                                            <input
                                                type="text"
                                                value={medication.duration}
                                                onChange={(e) => handleMedicationChange(index, 'duration', e.target.value)}
                                                required
                                                className="w-full p-2 border border-gray-300 dark:border-gray-700 rounded-md focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-800"
                                            />
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>

                        <div className="space-y-2">
                            <label htmlFor="instructions" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                                Instructions et remarques
                            </label>
                            <textarea
                                id="instructions"
                                name="instructions"
                                value={formData.instructions}
                                onChange={handleChange}
                                rows={4}
                                className="w-full p-2 border border-gray-300 dark:border-gray-700 rounded-md focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-800"
                            ></textarea>
                        </div>
                    </div>

                    <div className="flex justify-end space-x-4">
                        <Button
                            type="button"
                            onClick={() => router.back()}
                            variant="outline"
                            className="px-4 py-2"
                        >
                            Annuler
                        </Button>
                        <Button
                            type="submit"
                            disabled={isSubmitting}
                            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2"
                        >
                            {isSubmitting ? 'Enregistrement...' : 'Enregistrer'}
                        </Button>
                    </div>
                </form>
            </div>
        </div>
    );
}