'use client';

import { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';

type Prescription = {
  id: string;
  patientName: string;
  date: string;
  medications: Array<{
    name: string;
    dosage: string;
    frequency: string;
    duration: string;
  }>;
  instructions: string;
  doctorName: string;
  status: 'active' | 'completed' | 'cancelled';
};

export default function PrescriptionDetailPage() {
  const router = useRouter();
  const params = useParams();
  const prescriptionId = params.id as string;
  const [isLoading, setIsLoading] = useState(true);
  const [prescription, setPrescription] = useState<Prescription | null>(null);

  // Fetch prescription data
  useEffect(() => {
    // In a real application, you would fetch the data from your API
    // For now, we'll simulate fetching data
    const fetchData = () => {
      setIsLoading(true);
      
      // Mock data based on the prescription ID
      // In a real app, this would be an API call
      setTimeout(() => {
        // This is mock data - in a real app you would fetch from an API
        const mockPrescriptions = [
          {
            id: '1',
            patientName: 'Jean Dupont',
            date: '2023-06-15T10:30:00',
            medications: [
              {
                name: 'Amoxicilline',
                dosage: '500mg',
                frequency: '3 fois par jour',
                duration: '7 jours'
              },
              {
                name: 'Paracétamol',
                dosage: '1000mg',
                frequency: 'Si douleur, max 3 fois par jour',
                duration: 'Au besoin'
              }
            ],
            instructions: 'Prendre avec de la nourriture. Éviter l\'alcool pendant le traitement.',
            doctorName: 'Dr. Martin',
            status: 'active'
          },
          {
            id: '2',
            patientName: 'Marie Martin',
            date: '2023-06-18T15:45:00',
            medications: [
              {
                name: 'Amlodipine',
                dosage: '5mg',
                frequency: '1 fois par jour',
                duration: '30 jours'
              }
            ],
            instructions: 'Prendre le matin. Surveiller la tension artérielle régulièrement.',
            doctorName: 'Dr. Dubois',
            status: 'active'
          },
          {
            id: '3',
            patientName: 'Pierre Durand',
            date: '2023-05-20T09:15:00',
            medications: [
              {
                name: 'Ibuprofène',
                dosage: '400mg',
                frequency: '3 fois par jour',
                duration: '5 jours'
              }
            ],
            instructions: 'Prendre après les repas. Arrêter si douleurs gastriques.',
            doctorName: 'Dr. Martin',
            status: 'completed'
          }
        ];
        
        const foundPrescription = mockPrescriptions.find(p => p.id === prescriptionId);
        
        if (foundPrescription) {
          // Ensure the status is properly typed as the union type
          setPrescription({
            ...foundPrescription,
            status: foundPrescription.status as 'active' | 'completed' | 'cancelled'
          });
        } else {
          // Handle case where prescription is not found
          router.push('/prescriptions');
        }
        
        setIsLoading(false);
      }, 1000);
    };
    
    fetchData();
  }, [prescriptionId, router]);

  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Get status badge class
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'completed':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'cancelled':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
    }
  };

  // Get status label
  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'active':
        return 'Active';
      case 'completed':
        return 'Terminée';
      case 'cancelled':
        return 'Annulée';
      default:
        return status;
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-center items-center h-64">
          <p className="text-gray-500 dark:text-gray-400">Chargement des données...</p>
        </div>
      </div>
    );
  }

  if (!prescription) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-center items-center h-64">
          <p className="text-gray-500 dark:text-gray-400">Prescription non trouvée</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-blue-700">Détails de la Prescription</h1>
        <div className="flex space-x-3">
          {prescription.status === 'active' && (
            <Link href={`/prescriptions/${prescription.id}/edit`}>
              <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                Modifier
              </Button>
            </Link>
          )}
          <Link href="/prescriptions">
            <Button variant="outline">
              Retour à la liste
            </Button>
          </Link>
        </div>
      </div>
      
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <div className="flex justify-between items-start mb-6">
          <div>
            <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-200">{prescription.patientName}</h2>
            <p className="text-gray-600 dark:text-gray-400 mt-1">
              Prescrit le {formatDate(prescription.date)} par {prescription.doctorName}
            </p>
          </div>
          <span className={`px-3 py-1 rounded-full text-sm ${getStatusBadgeClass(prescription.status)}`}>
            {getStatusLabel(prescription.status)}
          </span>
        </div>
        
        <div className="mb-6">
          <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300 mb-3">Médicaments</h3>
          <div className="space-y-4">
            {prescription.medications.map((medication, index) => (
              <div key={index} className="p-4 bg-gray-50 dark:bg-gray-700 rounded-md">
                <h4 className="font-medium text-gray-800 dark:text-gray-200 mb-2">{medication.name}</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-sm">
                  <div>
                    <span className="text-gray-600 dark:text-gray-400">Dosage: </span>
                    <span className="text-gray-800 dark:text-gray-200">{medication.dosage}</span>
                  </div>
                  <div>
                    <span className="text-gray-600 dark:text-gray-400">Fréquence: </span>
                    <span className="text-gray-800 dark:text-gray-200">{medication.frequency}</span>
                  </div>
                  <div>
                    <span className="text-gray-600 dark:text-gray-400">Durée: </span>
                    <span className="text-gray-800 dark:text-gray-200">{medication.duration}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
          <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300 mb-2">Instructions</h3>
          <p className="text-gray-800 dark:text-gray-200 whitespace-pre-line">
            {prescription.instructions || (
              <span className="text-gray-500 dark:text-gray-400 italic">Aucune instruction</span>
            )}
          </p>
        </div>
      </div>
    </div>
  );
}