'use client';

import { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import Link from 'next/link';
import { Button } from '@/components/ui/button';

type Consultation = {
  id: string;
  patientName: string;
  date: string;
  time: string;
  reason: string;
  diagnosis: string;
  treatment: string;
  notes: string;
  status: 'terminé' | 'programmé' | 'annulé';
};

export default function ConsultationDetailPage() {
  const router = useRouter();
  const params = useParams();
  const consultationId = params.id as string;
  const [isLoading, setIsLoading] = useState(true);
  const [consultation, setConsultation] = useState<Consultation | null>(null);

  // Fetch consultation data
  useEffect(() => {
    // In a real application, you would fetch the data from your API
    // For now, we'll simulate fetching data
    const fetchData = () => {
      setIsLoading(true);
      
      // Mock data based on the consultation ID
      // In a real app, this would be an API call
      setTimeout(() => {
        // This is mock data - in a real app you would fetch from an API
        const mockConsultations = [
          {
            id: '1',
            patientName: 'Kwame Mensah',
            date: '2023-06-15',
            time: '09:00',
            reason: 'Douleurs abdominales',
            diagnosis: 'Gastro-entérite',
            treatment: 'Repos, hydratation, médicaments anti-douleur',
            notes: 'Patient à revoir dans une semaine si les symptômes persistent.',
            status: 'terminé' 
          },
          {
            id: '2',
            patientName: 'Amina Traoré',
            date: '2023-06-18',
            time: '14:30',
            reason: 'Suivi traitement hypertension',
            diagnosis: 'Hypertension contrôlée',
            treatment: 'Continuer le traitement actuel',
            notes: 'Prochain rendez-vous dans 3 mois.',
            status: 'terminé'
          },
          {
            id: '3',
            patientName: 'Abdoulaye Diouf',
            date: '2023-06-20',
            time: '11:00',
            reason: 'Examen annuel',
            diagnosis: '',
            treatment: '',
            notes: '',
            status: 'programmé' 
          }
        ];
        
        const foundConsultation = mockConsultations.find(c => c.id === consultationId);
        
        if (foundConsultation) {
          // Ensure the status is properly typed as the union type
          setConsultation({
            ...foundConsultation,
            status: foundConsultation.status as 'terminé' | 'programmé' | 'annulé'
          });
        } else {
          // Handle case where consultation is not found
          router.push('/consultations');
        }
        
        setIsLoading(false);
      }, 1000);
    };
    
    fetchData();
  }, [consultationId, router]);

  // Format date for display
  const formatDate = (date: string, time: string) => {
    const dateObj = new Date(`${date}T${time}`);
    return dateObj.toLocaleDateString('fr-FR', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Get status badge class
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300';
      case 'scheduled':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300';
      case 'cancelled':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300';
    }
  };

  // Get status label
  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'completed':
        return 'Terminée';
      case 'scheduled':
        return 'Planifiée';
      case 'cancelled':
        return 'Annulée';
      default:
        return status;
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-center items-center h-64">
          <p className="text-gray-500 dark:text-gray-400">Chargement des données...</p>
        </div>
      </div>
    );
  }

  if (!consultation) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-center items-center h-64">
          <p className="text-gray-500 dark:text-gray-400">Consultation non trouvée</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-blue-700">Détails de la Consultation</h1>
        <div className="flex space-x-3">
          {consultation.status === 'programmé' && (
            <Link href={`/consultations/${consultation.id}/edit`}>
              <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                Modifier
              </Button>
            </Link>
          )}
          <Link href="/consultations">
            <Button variant="outline">
              Retour à la liste
            </Button>
          </Link>
        </div>
      </div>
      
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
        <div className="flex justify-between items-start mb-6">
          <div>
            <h2 className="text-2xl font-semibold text-gray-800 dark:text-gray-200">{consultation.patientName}</h2>
            <p className="text-gray-600 dark:text-gray-400 mt-1">
              {formatDate(consultation.date, consultation.time)}
            </p>
          </div>
          <span className={`px-3 py-1 rounded-full text-sm ${getStatusBadgeClass(consultation.status)}`}>
            {getStatusLabel(consultation.status)}
          </span>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300">Motif de consultation</h3>
              <p className="text-gray-800 dark:text-gray-200 mt-1">{consultation.reason}</p>
            </div>
            
            <div>
              <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300">Diagnostic</h3>
              <p className="text-gray-800 dark:text-gray-200 mt-1">
                {consultation.diagnosis || (
                  <span className="text-gray-500 dark:text-gray-400 italic">En attente</span>
                )}
              </p>
            </div>
          </div>
          
          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300">Traitement</h3>
              <p className="text-gray-800 dark:text-gray-200 mt-1">
                {consultation.treatment || (
                  <span className="text-gray-500 dark:text-gray-400 italic">En attente</span>
                )}
              </p>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
          <h3 className="text-lg font-medium text-gray-700 dark:text-gray-300 mb-2">Notes</h3>
          <p className="text-gray-800 dark:text-gray-200 whitespace-pre-line">
            {consultation.notes || (
              <span className="text-gray-500 dark:text-gray-400 italic">Aucune note</span>
            )}
          </p>
        </div>
      </div>
    </div>
  );
}