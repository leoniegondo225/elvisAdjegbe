'use client';

import { useState, useEffect } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { Button } from '@/components/ui/button';

export default function EditConsultationPage() {
    const router = useRouter();
    const params = useParams();
    const consultationId = params.id as string;
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isLoading, setIsLoading] = useState(true);

    // Form state
    const [formData, setFormData] = useState({
        patientName: '',
        date: '',
        time: '',
        reason: '',
        diagnosis: '',
        treatment: '',
        notes: ''
    });

    // Récupérer les données de consultation
    useEffect(() => {
        // Dans une application réelle, vous récupéreriez les données à partir de votre API
        // Pour l'instant, nous allons simuler la récupération de données
        const fetchData = () => {
            setIsLoading(true);

            // Données fictives basées sur l'ID de consultation
            // Dans une application réelle, il s'agirait d'un appel d'API
            setTimeout(() => {
                // Il s'agit de données fictives - dans une application réelle, vous récupéreriez à partir d'une API
                const mockConsultations = [
                    {
                        "id": "1",
                        "patientName": "Abdoulaye Ndiaye",
                        "date": "2023-06-15",
                        "time": "09:00",
                        "reason": "Douleurs abdominales",
                        "diagnosis": "Gastro-entérite",
                        "treatment": "Repos, hydratation, médicaments anti-douleur",
                        "notes": "Patient à revoir dans une semaine si les symptômes persistent.",
                        "status": "completed"
                    },
                    {
                        "id": "2",
                        "patientName": "Aminata Sow",
                        "date": "2023-06-18",
                        "time": "14:30",
                        "reason": "Suivi traitement hypertension",
                        "diagnosis": "Hypertension contrôlée",
                        "treatment": "Continuer le traitement actuel",
                        "notes": "Prochain rendez-vous dans 3 mois.",
                        "status": "completed"
                    },
                    {
                        "id": "3",
                        "patientName": "Moussa Diouf",
                        "date": "2023-06-20",
                        "time": "11:00",
                        "reason": "Examen annuel",
                        "diagnosis": "",
                        "treatment": "",
                        "notes": "",
                        "status": "scheduled"
                    }
                ];

                const consultation = mockConsultations.find(c => c.id === consultationId);

                if (consultation) {
                    // Formatez la date et l'heure à partir de la chaîne ISO si nécessaire
                    setFormData({
                        patientName: consultation.patientName,
                        date: consultation.date,
                        time: consultation.time,
                        reason: consultation.reason,
                        diagnosis: consultation.diagnosis || '',
                        treatment: consultation.treatment || '',
                        notes: consultation.notes || ''
                    });
                } else {
                    // Gérer le cas où la consultation n'est pas trouvée
                    router.push('/consultations');
                }

                setIsLoading(false);
            }, 1000);
        };

        fetchData();
    }, [consultationId, router]);

    //  Gérer les modifications de saisie du formulaire
    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    // Gérer la soumission du formulaire
    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        setIsSubmitting(true);

        // Ici, vous enverriez généralement les données à votre API
        // Pour l'instant, nous allons simplement simuler une soumission
        setTimeout(() => {
            setIsSubmitting(false);
            // Revenir à la liste des consultations 
            router.push('/consultations');
        }, 1500);
    };

    if (isLoading) {
        return (
            <div className="container mx-auto px-4 py-8">
                <div className="flex justify-center items-center h-64">
                    <p className="text-gray-500 dark:text-gray-400">Chargement des données...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="container mx-auto px-4 py-8">
            <div className="mb-6">
                <h1 className="text-3xl font-bold text-blue-700">Modifier la Consultation</h1>
                <p className="text-gray-600 dark:text-gray-400 mt-2">Modifiez les informations de la consultation</p>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
                <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="space-y-2">
                            <label htmlFor="patientName" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                                Nom du patient
                            </label>
                            <input
                                type="text"
                                id="patientName"
                                name="patientName"
                                value={formData.patientName}
                                onChange={handleChange}
                                required
                                className="w-full p-2 border border-gray-300 dark:border-gray-700 rounded-md focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-800"
                            />
                        </div>

                        <div className="space-y-2">
                            <label htmlFor="date" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                                Date
                            </label>
                            <input
                                type="date"
                                id="date"
                                name="date"
                                value={formData.date}
                                onChange={handleChange}
                                required
                                className="w-full p-2 border border-gray-300 dark:border-gray-700 rounded-md focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-800"
                            />
                        </div>

                        <div className="space-y-2">
                            <label htmlFor="time" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                                Heure
                            </label>
                            <input
                                type="time"
                                id="time"
                                name="time"
                                value={formData.time}
                                onChange={handleChange}
                                required
                                className="w-full p-2 border border-gray-300 dark:border-gray-700 rounded-md focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-800"
                            />
                        </div>

                        <div className="space-y-2">
                            <label htmlFor="reason" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                                Motif de consultation
                            </label>
                            <input
                                type="text"
                                id="reason"
                                name="reason"
                                value={formData.reason}
                                onChange={handleChange}
                                required
                                className="w-full p-2 border border-gray-300 dark:border-gray-700 rounded-md focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-800"
                            />
                        </div>

                        <div className="space-y-2">
                            <label htmlFor="diagnosis" className="block text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                                </svg>
                                Diagnostic
                            </label>
                            <div className="relative">
                                <input
                                    type="text"
                                    id="diagnosis"
                                    name="diagnosis"
                                    value={formData.diagnosis}
                                    onChange={handleChange}
                                    className="w-full p-2 pl-3 border border-gray-300 dark:border-gray-700 rounded-md focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-800"
                                    placeholder="Entrez le diagnostic médical"
                                />
                            </div>
                        </div>

                        <div className="space-y-2">
                            <label htmlFor="treatment" className="block text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                                </svg>
                                Traitement
                            </label>
                            <div className="relative">
                                <input
                                    type="text"
                                    id="treatment"
                                    name="treatment"
                                    value={formData.treatment}
                                    onChange={handleChange}
                                    className="w-full p-2 pl-3 border border-gray-300 dark:border-gray-700 rounded-md focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-800"
                                    placeholder="Prescriptions et recommandations"
                                />
                            </div>
                        </div>
                    </div>

                    <div className="space-y-2">
                        <label htmlFor="notes" className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                            Notes additionnelles
                        </label>
                        <textarea
                            id="notes"
                            name="notes"
                            value={formData.notes}
                            onChange={handleChange}
                            rows={4}
                            className="w-full p-2 border border-gray-300 dark:border-gray-700 rounded-md focus:ring-blue-500 focus:border-blue-500 bg-white dark:bg-gray-800"
                        ></textarea>
                    </div>

                    <div className="flex justify-end space-x-4">
                        <Button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2"
                            type="button"
                            onClick={() => router.back()}
                            variant="outline"
                        >
                            Annuler
                        </Button>
                        <Button className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2"
                            type="submit"
                            disabled={isSubmitting}
                        >
                            {isSubmitting ? 'Enregistrement...' : 'Enregistrer'}
                        </Button>
                    </div>
                </form>
            </div>
        </div>
    );
}