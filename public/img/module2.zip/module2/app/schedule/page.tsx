import { Calendar } from '@/components/schedule/Calendar';
import AppointmentForm from '@/components/schedule/AppointmentForm';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function SchedulePage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold text-blue-700 mb-6">Agenda du Médecin</h1>
      
      <Tabs defaultValue="calendar" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="calendar">Calendrier</TabsTrigger>
          <TabsTrigger value="list">Liste des Rendez-vous</TabsTrigger>
          <TabsTrigger value="new">Nouveau Rendez-vous</TabsTrigger>
        </TabsList>
        
        <TabsContent value="calendar" className="space-y-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <Calendar />
          </div>
        </TabsContent>
        
        <TabsContent value="list" className="space-y-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4">Rendez-vous à venir</h2>
            <p className="text-gray-500 dark:text-gray-400 italic">Fonctionnalité en cours de développement</p>
            {/* Liste des rendez-vous sera implémentée ici */}
          </div>
        </TabsContent>
        
        <TabsContent value="new" className="space-y-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold mb-4">Planifier un nouveau rendez-vous</h2>
            <AppointmentForm />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}